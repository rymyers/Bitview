class Account < ActiveRecord::Base
end
