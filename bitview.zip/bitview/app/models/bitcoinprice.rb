class Bitcoinprice < ActiveRecord::Base
end
